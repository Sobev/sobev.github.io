#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
  @author luojx
  @date ${DATE} ${TIME}
*/
public record ${NAME}() {
}
